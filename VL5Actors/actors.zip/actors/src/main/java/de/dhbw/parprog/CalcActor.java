package de.dhbw.parprog;

import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;
import scala.NotImplementedError;


public class CalcActor extends AbstractBehavior<CalcActor.Command> {
    public interface Command { }

    public static Behavior<Command> create() {
        return Behaviors.setup(CalcActor::new);
    }

    private CalcActor(ActorContext<Command> context) {
        super(context);
    }

    @Override
    public Receive<Command> createReceive() {
        // TODO: Eigene Implementierung hier einfügen
        throw new NotImplementedError();
    }
}
