package de.dhbw.parprog;

import java.io.File;
import java.io.IOException;

import akka.actor.ActorSystem;
import org.apache.commons.lang.NotImplementedException;


public class ActorDirSize {
	public DirStats dirStats(File dir) {
        // TODO: Mit Akka verteilte Berechnung hier einfügen
        throw new NotImplementedException();
	}

	public static void main(String[] args) {
		if (args.length<1) {
			System.out.println("Benötigter Parameter: Startverzeichnis");
			System.exit(1);
		}
		File startDir = new File(args[0]);
		if (!startDir.isDirectory()) {
			System.out.println("Dies ist kein Verzeichnis!");
			System.exit(1);
		}
		
		ActorDirSize test = new ActorDirSize();
		DirStats result = test.dirStats(startDir);
		System.out.println(result.fileCount + " Dateien, " + result.totalSize + " Bytes.");
	}
}
