package de.dhbw.parprog;

import akka.actor.typed.ActorSystem;
import akka.actor.typed.SupervisorStrategy;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.PoolRouter;
import akka.actor.typed.javadsl.Routers;
import scala.NotImplementedError;


public class ActorCalculation {
    public int doCalculation() {
        final ActorSystem<CalcActor.Command> system = ActorSystem.create(???, "calc");

        // TODO: Eigene Implementierung hier einfügen
        throw new NotImplementedError();

        try {
            Thread.sleep(500);
        } catch (InterruptedException ignore) { }
        system.terminate();
        system.getWhenTerminated()
                .thenAccept((done) -> System.out.println("Bye bye!"));
    }

	public static void main(String[] args) {
        ActorCalculation calc = new ActorCalculation();
        System.out.println("Important calculation - with actors");
        System.out.println("The result is " + calc.doCalculation());
    }
}
